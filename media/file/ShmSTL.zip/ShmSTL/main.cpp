#include <stdio.h>
#include "ShmMemory.h"
#include "ShmSTL.h"

#define BUF_SIZE 256*1024*1024

#ifdef WIN32
	char  g_tKey[] = {"mdb_key_test"};
#else 
	long long g_tKey = 0x123456;
#endif

int g_iSEQ = 0;
//��ȡseq
int GetSeq()
{
	return g_iSEQ++;
}

int TestShmMemory()
{
	int iRet = 0;
	SHAMEM_T iShmID = INITVAl;
	if(TShmMemory::IsShmExist(g_tKey,BUF_SIZE,iShmID))
	{//�Ѵ���
		printf("Shm exist ,iShmID == "SHMID_FMT"\n",iShmID);
	}
	else
	{//������
		printf("Shm not exist,try to create.\n");
		CHECK_RET(TShmMemory::Create(g_tKey,BUF_SIZE,iShmID),"Create failed.");
		printf("iShmID == "SHMID_FMT"\n",iShmID);
	}
	char * pAddr = NULL;
	CHECK_RET(TShmMemory::AttachByID(iShmID,pAddr),"AttachByID failed.");
	printf("attach addr = [%p],value=[%s]\n",pAddr,pAddr);
	sprintf(pAddr,"%s,"SHMID_FMT,pAddr,iShmID);
	int i = 0;
	scanf("%d",i);
	return iRet;
}
//��������
class TTestData
{
public:
	TTestData():m_iID(0),m_StartAddr(NULL)
	{
		sprintf(m_str,"%d",GetSeq());
	}
public:
	SHAMEM_T m_iID;
	char m_str[16];
	char * m_StartAddr;
};
//��ӡ
int Print(TShmList<TTestData> & tList,const char * sTip = NULL)
{
	if(sTip != NULL)
	{
		printf("{%s}\n",sTip);
	}
	TShmList<TTestData>::iterator itor = tList.begin();
	printf("[start,size=[%d]======]\n",tList.size());
	for(;itor != tList.end();++itor)
	{
		printf("["SHMID_FMT"][%s][%p]\n",itor->m_iID,itor->m_str,itor->m_StartAddr);
	}
	printf("[end,is-empty[%d]=====]\n\n",tList.empty());
	return 0;
}
//��Ԫ����
int UnitTest(TShmList<TTestData> & tList)
{
	Print(tList,"UnitTest begin");

	tList.insert(tList.begin());
	tList.insert(tList.begin());
	Print(tList,"After insert begin");

	tList.insert(tList.end());
	tList.insert(tList.end());
	Print(tList,"After insert end()");

	TTestData tempData;
	tList.push_back(tempData);
	Print(tList,"After push_back");

	tList.push_front(tempData);
	Print(tList,"After push_front");

	tList.pop_back();
	Print(tList,"After pop_back");

	tList.pop_front();
	Print(tList,"After pop_front");

	tList.insert(++tList.begin(),tempData);
	Print(tList,"After insert begin + 1");

	tList.clear();
	Print(tList,"After clear");

	printf("{UnitTest End}\n");
	return 0;
}

//����main
int main(int argc,char * argv[])
{
	int iRet = 0;
	TShmAlloc tAlloc;
	SHAMEM_T iShmID = INITVAl;
	if(argc != 1)
	{//�����ڴ�
		if(TShmMemory::IsShmExist(g_tKey,BUF_SIZE,iShmID))	
		{
			TShmMemory::Destroy(iShmID);
			printf(SHMID_FMT" is destroyed\n",iShmID);
		}	
		return 0;
	}
	TShmList<TTestData> tShmList;
	if(false == TShmMemory::IsShmExist(g_tKey,BUF_SIZE,iShmID))
	{//�״δ���
		CHECK_RET(tAlloc.CreateShm(g_tKey,BUF_SIZE,iShmID),"CreateShm failed.");//�������״η����ڴ�
		printf("Shm not exist,try to create,ShmID="SHMID_FMT".\n",iShmID);
		tShmList.Attach(g_tKey,tAlloc.m_pShmHead->m_iListOffSet);//ShmList ��ʼ��
		UnitTest(tShmList);//���е�Ԫ����
	}
	else
	{//�����ڴ��Ѵ���
		char * pAddr = NULL;
		tAlloc.AttachByKey(g_tKey,pAddr);//��������ʼ��
		printf("Shm exist ,iShmID == "SHMID_FMT"\n",iShmID);
		tShmList.Attach(g_tKey,tAlloc.m_pShmHead->m_iListOffSet);//ShmList ��ʼ��
	}
	int iTotalCounts = 0;
	do 
	{
		int iCount = 1;
		scanf("%d",&iCount);
		int i = 0;
		if(iCount > 0)
		{
			for(i = 0;i< iCount;++i)
			{
				TTestData tData;
				tData.m_iID = iShmID;
				tData.m_StartAddr = tAlloc.GetStartAddr();
				tShmList.insert(tShmList.end(),tData);//�򵥵�stl������
			}	
		}
		else if (0 == iCount)
		{
			tShmList.clear();
		}
		else 
		{
			while(iCount ++)
			{
				tShmList.erase(tShmList.begin());
			}
		}
	    Print(tShmList);
	} while (1);
	return iRet;
}
