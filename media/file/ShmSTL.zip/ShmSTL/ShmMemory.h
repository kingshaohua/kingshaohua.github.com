#ifndef __SHARE_MEMORY_H__
#define __SHARE_MEMORY_H__

#ifdef  _WIN32
    #pragma warning(disable:4312)           //unsigned int ����int ת����HANDLE
    #pragma warning(disable:4311)           //void*ת����long
    #include <windows.h>
#else   //_UNIX
    #include <sys/shm.h>
    #include <stdlib.h>
    #include <sys/ipc.h>
    #include <errno.h>
    #include <signal.h>
#endif  //_WIN32 _UNIX

#ifdef WIN32
	typedef HANDLE          SHAMEM_T;
	#define INITVAl         NULL   
	#pragma warning(disable:4018)  
	#pragma warning(disable:4390) 
	typedef char*             SMKey; 
	#define SHMID_FMT        "%p"
#else
	typedef int             SHAMEM_T;
	typedef key_t			SMKey;
	#define INITVAl          -1
	#define SHMID_FMT        "%d"
#endif

#define MAX_SHM_COUNTS 100
class TGlobalShm
{
public:
    TGlobalShm()
    {
        iShmID = INITVAl;
        pAddr  = NULL;
    }
    SHAMEM_T iShmID;
    char* pAddr;
};

#define ERROR_OS_CREATE_SHM  -10001
#define ERROR_OS_ATTACH_SHM  -10002
#define ERROR_OS_DETACH_SHM  -10003
#define ERROR_OS_DESTROY_SHM -10004

class TShmMemory
{   
public:
    static bool IsShmExist(SMKey iShmKey, size_t iShmSize,SHAMEM_T & iShmID);
    static int Create(SMKey iShmKey, size_t iShmSize, SHAMEM_T & iShmID);
    static int AttachByID(SHAMEM_T iShmID, char* &pAddr);
    static int AttachByKey(SMKey iShmKey, char* &pAddr);
    static int Detach(char* pAddr);
    static int Destroy(SHAMEM_T iShmID);

public:
    static TGlobalShm tGlobalShm[MAX_SHM_COUNTS];
};
#endif
