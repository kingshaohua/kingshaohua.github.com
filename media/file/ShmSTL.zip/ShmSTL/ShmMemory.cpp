#include "ShmMemory.h"
#include "stdio.h"
#include <string.h>
#ifdef WIN32
#pragma warning(disable:4006)
#else

#endif

TGlobalShm TShmMemory::tGlobalShm[MAX_SHM_COUNTS];
/************************************************************************/
/* �жϹ����ڴ��Ƿ����                                                                     */
/************************************************************************/
bool TShmMemory::IsShmExist(SMKey iShmKey, size_t iShmSize,SHAMEM_T & iShmID)
{
#ifdef WIN32
	iShmID = OpenFileMapping(FILE_MAP_ALL_ACCESS,false,(char *) iShmKey);
#else
	iShmID = shmget(iShmKey, iShmSize, 0666 | IPC_EXCL);
#endif
    if(iShmID  != INITVAl)
    {
        return true;
    }
    else
    {
        return false;
    }
}
/************************************************************************/
/* ���������ڴ�                                                                     */
/************************************************************************/
int TShmMemory::Create(SMKey iShmKey, size_t iShmSize, SHAMEM_T & iShmID)
{
#ifdef WIN32
	iShmID = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,iShmSize,(char *)iShmKey);
	if(INITVAl == iShmID)
	{//����ʧ��
		printf("CreateShm failed,[%d]",GetLastError());
		return ERROR_OS_CREATE_SHM;
	}
	return 0;
#else
    //����Ҫ�ų��Դ��������ʧ�ܣ���ȡ���ų����Դ���
    iShmID = shmget(iShmKey, iShmSize, 0666|IPC_CREAT|IPC_EXCL);
    if(iShmID == -1)
    {
        iShmID = shmget(iShmKey, iShmSize, 0666|IPC_CREAT);  
        if(iShmID == -1)  
        {
            printf("CreateShm failed, iShmKey=%lld, iShmSize=%ld,errno=%d,errmsg=%s .",iShmKey, iShmSize,errno,strerror(errno));
            return ERROR_OS_CREATE_SHM;    
        }
    }
    else
    {
        return 0;    
    } 
	return 0;
#endif
}


/************************************************************************/
/* attach                                                                     */
/************************************************************************/
int TShmMemory::AttachByID(SHAMEM_T iShmID, char* &pAddr)
{   
	int i = 0;
	//����ȫ�ֻ���������
    for(i=0; i<MAX_SHM_COUNTS; ++i)
    {
        if(tGlobalShm[i].iShmID == iShmID)
        {
            pAddr = tGlobalShm[i].pAddr;
            return 0;
        }
    }
#ifdef WIN32
	pAddr = (char*)MapViewOfFile(iShmID, FILE_MAP_ALL_ACCESS,0,0,0);
#else
	pAddr = (char*)shmat(iShmID, 0, 0);
#endif
	if((char *)INITVAl == pAddr)
	{//ʧ��
		return ERROR_OS_ATTACH_SHM;
	}
	//��attach�ɹ����浽������
    for(i=0; i<MAX_SHM_COUNTS; ++i)
    {
        if(tGlobalShm[i].iShmID == INITVAl)
        {
            tGlobalShm[i].pAddr = pAddr;
            tGlobalShm[i].iShmID = iShmID;
            break;
        }
    }
    return 0;
}

/************************************************************************/
/* attach                                                                     */
/************************************************************************/
int TShmMemory::AttachByKey(SMKey iShmKey, char* &pAddr)
{
    //��ȡ�����ڴ��ʶID
	SHAMEM_T iShmID = INITVAl;
#ifdef WIN32
	iShmID = OpenFileMapping(FILE_MAP_ALL_ACCESS,false,(char *) iShmKey);
#else
	iShmID = shmget(iShmKey, 0, 0666);
#endif
	if(INITVAl == iShmID)
	{
		return ERROR_OS_CREATE_SHM;
	}     
    if(AttachByID(iShmID,pAddr) < 0)
    {
        return ERROR_OS_ATTACH_SHM;
    }
    return 0;
}


/************************************************************************/
/* detach                                                                     */
/************************************************************************/
int TShmMemory::Detach(char* pAddr)
{
#ifdef WIN32
	if(false == UnmapViewOfFile(pAddr))
	{
		return ERROR_OS_DETACH_SHM;
	}
#else
	int iRet = shmdt(pAddr);
    if(iRet != 0)
    {
		printf("errorno=%d, error-msg=%s\n,pAddr=%p", errno, strerror(errno),pAddr); 
        return ERROR_OS_DETACH_SHM;
    }
#endif
    return 0;
}
/************************************************************************/
/* destroy                                                                     */
/************************************************************************/
int TShmMemory::Destroy(SHAMEM_T iShmID)
{
#ifdef WIN32
	if(false == CloseHandle(iShmID))
	{
		return ERROR_OS_DESTROY_SHM;
	}
#else
    int iRet = shmctl(iShmID, IPC_RMID, 0);
    if(iRet != 0)
    {
    	printf("errorno=%d, error-msg=%s\n,iShmID=%d",errno, strerror(errno),iShmID); 
        return ERROR_OS_DESTROY_SHM;
    }
#endif
    return 0;
}
